import type {
  DetectedResource,
  ExtensionSettings,
} from "../../shared/contracts";
import {
  extensionFromUrl,
  filenameFromUrl,
  normalizeUrl,
} from "../../shared/urls";
import { classifyObservedRequest } from "./classifier";
import type { ResourceCache } from "./cache";

interface PendingRequest {
  requestId: string;
  tabId: number;
  frameId: number;
  url: string;
  documentUrl?: string;
  requestType?: string;
  startedAt: number;
  mime?: string;
  size?: number;
  filename?: string;
}

// A request that never fires onCompleted/onErrorOccurred (a long-lived
// SSE/EventSource connection kept open for a page's lifetime, or any request
// Firefox doesn't cleanly terminate) would otherwise sit in `pending`
// forever for as long as observation stays enabled.
const PENDING_TTL_MS = 5 * 60 * 1_000;
const PENDING_SWEEP_INTERVAL_MS = 60 * 1_000;

export class NetworkObserver {
  private pending = new Map<string, PendingRequest>();
  private registered = false;
  private sweepTimer: number | null = null;

  constructor(private readonly cache: ResourceCache) {}

  async synchronize(settings: ExtensionSettings): Promise<void> {
    const hasPermissions = await browser.permissions.contains({
      permissions: ["webRequest"],
      origins: ["<all_urls>"],
    });
    const shouldRegister = settings.networkObservation && hasPermissions;
    if (shouldRegister && !this.registered) this.register();
    if (!shouldRegister && this.registered) this.unregister();
  }

  private register(): void {
    browser.webRequest.onBeforeRequest.addListener(this.onBeforeRequest, {
      urls: ["<all_urls>"],
    });
    browser.webRequest.onBeforeRedirect.addListener(this.onBeforeRedirect, {
      urls: ["<all_urls>"],
    });
    browser.webRequest.onHeadersReceived.addListener(
      this.onHeadersReceived,
      { urls: ["<all_urls>"] },
      ["responseHeaders"],
    );
    browser.webRequest.onCompleted.addListener(this.onCompleted, {
      urls: ["<all_urls>"],
    });
    browser.webRequest.onErrorOccurred.addListener(this.onError, {
      urls: ["<all_urls>"],
    });
    this.sweepTimer = window.setInterval(
      () => this.sweepPending(),
      PENDING_SWEEP_INTERVAL_MS,
    );
    this.registered = true;
  }

  private unregister(): void {
    browser.webRequest.onBeforeRequest.removeListener(this.onBeforeRequest);
    browser.webRequest.onBeforeRedirect.removeListener(this.onBeforeRedirect);
    browser.webRequest.onHeadersReceived.removeListener(this.onHeadersReceived);
    browser.webRequest.onCompleted.removeListener(this.onCompleted);
    browser.webRequest.onErrorOccurred.removeListener(this.onError);
    if (this.sweepTimer !== null) window.clearInterval(this.sweepTimer);
    this.sweepTimer = null;
    this.pending.clear();
    this.registered = false;
  }

  private sweepPending(): void {
    const cutoff = Date.now() - PENDING_TTL_MS;
    for (const [requestId, request] of this.pending)
      if (request.startedAt < cutoff) this.pending.delete(requestId);
  }

  private readonly onBeforeRequest = (
    details: browser.webRequest._OnBeforeRequestDetails,
  ): void => {
    if (details.tabId < 0 || details.method !== "GET") return;
    const url = normalizeUrl(details.url);
    if (!url) return;
    this.pending.set(details.requestId, {
      requestId: details.requestId,
      tabId: details.tabId,
      frameId: details.frameId,
      url,
      documentUrl: details.documentUrl,
      requestType: details.type,
      startedAt: Date.now(),
    });
  };

  private readonly onBeforeRedirect = (
    details: browser.webRequest._OnBeforeRedirectDetails,
  ): void => {
    const request = this.pending.get(details.requestId);
    if (!request) return;
    // Catalogue the resource under the URL it actually ended up at — the
    // original request URL is often a short-lived CDN/signed-URL redirect
    // that won't resolve to the same content later.
    const redirected = normalizeUrl(details.redirectUrl);
    if (redirected) request.url = redirected;
  };

  private readonly onHeadersReceived = (
    details: browser.webRequest._OnHeadersReceivedDetails,
  ): void => {
    const request = this.pending.get(details.requestId);
    if (!request) return;
    request.mime = header(details.responseHeaders, "content-type")
      ?.split(";", 1)[0]
      ?.trim();
    const length = Number(header(details.responseHeaders, "content-length"));
    if (Number.isFinite(length) && length >= 0) request.size = length;
    request.filename = filenameFromDisposition(
      header(details.responseHeaders, "content-disposition"),
    );
  };

  private readonly onCompleted = (
    details: browser.webRequest._OnCompletedDetails,
  ): void => {
    const request = this.pending.get(details.requestId);
    this.pending.delete(details.requestId);
    if (!request) return;
    const classification = classifyObservedRequest(
      request.url,
      request.mime,
      request.requestType,
    );
    if (classification.ignore) {
      // A segment with no manifest in sight (the player fetched the
      // manifest through a path we can't observe, e.g. a blob: URL) still
      // means there's a stream here — surface a hint instead of dropping it
      // entirely, without cluttering the resource list with hundreds of
      // individual .ts/.m4s entries.
      if (classification.isSegment) this.cache.markStreamHint(request.tabId);
      return;
    }
    const resource: DetectedResource = {
      id: `network:${request.requestId}`,
      url: request.url,
      normalizedUrl: request.url,
      pageUrl: request.documentUrl ?? request.url,
      frameUrl: request.documentUrl,
      type: classification.kind,
      mime: request.mime,
      extension: extensionFromUrl(request.url),
      filename: request.filename ?? filenameFromUrl(request.url),
      size: request.size,
      source: "webRequest",
      confidence: request.mime ? 0.95 : 0.75,
      discoveredAt: Date.now(),
    };
    this.cache.merge(request.tabId, [resource]);
    void browser.runtime
      .sendMessage({ type: "ravyn-resources-updated", tabId: request.tabId })
      .catch(() => undefined);
  };

  private readonly onError = (
    details: browser.webRequest._OnErrorOccurredDetails,
  ): void => {
    this.pending.delete(details.requestId);
  };
}

function header(
  headers: browser.webRequest.HttpHeaders | undefined,
  name: string,
): string | undefined {
  return headers?.find((item) => item.name.toLowerCase() === name)?.value;
}

function filenameFromDisposition(
  value: string | undefined,
): string | undefined {
  if (!value) return undefined;
  const utf8 = /filename\*=UTF-8''([^;]+)/i.exec(value)?.[1];
  if (utf8) {
    try {
      return decodeURIComponent(utf8).slice(0, 255);
    } catch {
      return utf8.slice(0, 255);
    }
  }
  return /filename="?([^";]+)"?/i.exec(value)?.[1]?.trim().slice(0, 255);
}
